import os
import sys
import random
import pygame
import sqlite3
from PyQt5 import uic
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *

pygame.init()
pygame.display.set_caption('PyGame Project')
FPS = 50
size = width, height = 600, 750
screen = pygame.display.set_mode(size)
background_image = pygame.image.load('data/fon2.png').convert()
background_image = pygame.transform.scale(background_image, (700, 750))
background_image_bad = pygame.image.load('data/bad.png').convert()
background_image_bad = pygame.transform.scale(background_image_bad, (700, 750))
background_image_sun = pygame.image.load('data/sun.png').convert()
background_image_sun = pygame.transform.scale(background_image_sun, (700, 750))
background_image_nrm = pygame.image.load('data/norm.jpg').convert()
background_image_nrm = pygame.transform.scale(background_image_nrm, (700, 750))
clock = pygame.time.Clock()
list_image = [background_image_bad, background_image_nrm,
              background_image, background_image_sun]
xxx = [["banana.png", 120, 120], ["burger.png", 120, 120],
       ["apple.png", 100, 120], ["strawberry.png", 100, 120],
       ["kiwi.png", 140, 120], ["cake.png", 110, 120],
       ["cherry.png", 100, 130], ["pizza.png", 120, 120],
       ["ice.png", 110, 150], ["orange.png", 120, 120],
       ["spag.png", 175, 100]]


class Dialog(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Таблица с результатами')
        uic.loadUi('table.ui', self)
        self.connection = sqlite3.connect('play.db')
        self.create()

    def create(self):
        query = "Select name, очки from player ORDER BY очки"
        res = self.connection.cursor().execute(query).fetchall()[::-1]
        self.tableWidget.setColumnCount(2)
        self.tableWidget.setRowCount(0)
        self.tableWidget.setHorizontalHeaderLabels(['Имя', 'Счёт за игру'])
        for i, row in enumerate(res):
            self.tableWidget.setRowCount(self.tableWidget.rowCount() + 1)
            for j, elem in enumerate(row):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(elem)))


class Wind(QMainWindow):
    def __init__(self, ch):
        super().__init__()
        self.setWindowTitle('Ваше имя')
        uic.loadUi('u.ui', self)
        self.ch = ch
        self.connection = sqlite3.connect('play.db')
        self.but.clicked.connect(self.add)

    def add(self):
        name = self.name.toPlainText()
        if name == "":
            name = "No name%s" % (random.randint(1, 1000))
        c = self.connection.cursor()
        c.execute('''INSERT INTO player (name, очки)
                            VALUES (?, ?)''', (name, self.ch))
        self.connection.commit()
        self.close()


def sql():
    app2 = QApplication(sys.argv)
    m = Dialog()
    m.show()
    sys.exit(app2.exec())


def sql_table(ch):
    app = QApplication(sys.argv)
    ex = Wind(ch)
    ex.show()
    if app.exec() == 0:
        sql()


def terminate():
    pygame.quit()
    sys.exit()


def end_screen(p):
    all_sprites7 = pygame.sprite.Group()
    sprite7 = pygame.sprite.Sprite()
    sprite7.image = load_image(["kur.png", 100, 100])
    sprite7.rect = sprite7.image.get_rect()
    all_sprites7.add(sprite7)
    sprite7.rect.x = 5
    sprite7.rect.y = 20
    pygame.mouse.set_visible(False)
    clock2 = pygame.time.Clock()
    size = width, height = 600, 300
    screen9 = pygame.display.set_mode(size)
    x_pos = 200 * clock2.tick() / 800
    all_sprites = pygame.sprite.Group()
    player = Game()
    all_sprites.add(player)
    run = True
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                sys.exit()
            if event.type == pygame.MOUSEMOTION:
                sprite7.rect.x = event.pos[0]
                sprite7.rect.y = event.pos[1]
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    pygame.display.quit()
                    pygame.quit()
                    sql_table(p)
                    return
        screen.fill((255, 0, 0))
        all_sprites7.draw(screen9)
        x_pos += 200 * clock2.tick() / 800
        all_sprites.update(x_pos)
        all_sprites7.draw(screen9)
        pygame.display.flip()


def end_screen_true(p):
    pygame.mouse.set_visible(True)
    clock1 = pygame.time.Clock()
    clock1.tick(1)
    fon = load_image(['end.jpeg', 600, 464])
    size = width, height = 600, 464
    screen = pygame.display.set_mode(size)
    screen.blit(fon, (0, 0))
    while True:
        for u in pygame.event.get():
            if u.type == pygame.QUIT:
                terminate()
            elif u.type == pygame.MOUSEBUTTONDOWN:
                pygame.display.quit()
                pygame.quit()
                sql_table(p)
                return
        pygame.display.flip()


def start_screen():
    all_sprites5 = pygame.sprite.Group()
    sprite5 = pygame.sprite.Sprite()
    sprite5.image = load_image(["kur.png", 100, 100])
    sprite5.rect = sprite5.image.get_rect()
    all_sprites5.add(sprite5)
    sprite5.rect.x = 5
    sprite5.rect.y = 20
    pygame.mouse.set_visible(False)
    fon = load_image(['fon.jpeg'])
    background_image6 = pygame.transform.scale(fon, (600, 750))
    screen.blit(background_image6, (0, 0))
    while True:
        for u in pygame.event.get():
            if u.type == pygame.QUIT:
                terminate()
            if u.type == pygame.MOUSEMOTION:
                sprite5.rect.x = u.pos[0]
                sprite5.rect.y = u.pos[1]
            elif u.type == pygame.MOUSEBUTTONDOWN:
                return
        screen.blit(background_image6, (0, 0))
        all_sprites5.draw(screen)
        pygame.display.flip()


def rules():
    pygame.mouse.set_visible(True)
    intro_text = ["Правила игры:",
                  "Нужно поймать продукты ПП.",
                  "(за пропуск полезной или попадание на",
                  "вредную еду - штраф в -10 очков)",
                  "Игрок побеждает при счёте: 600;",
                  "Или проигрывает при -50 очках."]
    fon = load_image(['fon.png'])
    size = width, height = 700, 300
    screen = pygame.display.set_mode(size)
    background_image5 = pygame.transform.scale(fon, (700, 300))
    screen.blit(background_image5, (0, 0))
    text_coord = 35
    font = pygame.font.Font(None, 40)
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 0
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)
    while True:
        for u in pygame.event.get():
            if u.type == pygame.QUIT:
                terminate()
            elif u.type == pygame.MOUSEBUTTONDOWN:
                return
        pygame.display.flip()


def load_image(name):
    fullname = os.path.join('data', name[0])
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname).convert_alpha()
    if name[0] != "fon.jpeg" and name[0] != "fon.png" \
       and name[0] != "gameover.png" and name[0] != "star.png":
        image = pygame.transform.scale(image, (name[1], name[2]))
    return image


class Game(pygame.sprite.Sprite):
    image = load_image(["gameover.png"])

    def __init__(self, *group):
        super().__init__(*group)
        self.image = Game.image
        self.rect = self.image.get_rect()
        self.rect.x = 0
        self.rect.y = 0

    def update(self, x):
        self.rect.x = x
        screen.fill((255, 0, 0))
        if x < 600:
            screen.blit(self.image, (0, 0), (600 - x, 0, 600, 300))
        else:
            screen.blit(self.image, (0, 0))


class Food(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__(all_sprites)
        list_healthy_food = ["banana.png", "apple.png", "strawberry.png",
                             "kiwi.png", "cherry.png", "orange.png"]
        p = random.choice(xxx)
        image = dict_image[p[0]]
        self.image = image
        self.rect = self.image.get_rect()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect.x = pos[0]
        self.rect.y = pos[1]
        if p[0] in list_healthy_food:
            self.food = 1
        else:
            self.food = 0
        if pygame.sprite.spritecollideany(self, horizontal_borders):
            all_sprites.remove(self)
            horizontal_borders.remove(self)
        else:
            horizontal_borders.add(self)

    def update(self, p=None):
        global all_sprites, check, flag_p
        if p:
            x1, y1 = p[0], p[1]
            f = False
            a1, b1 = self.rect[0], self.rect[1]
            if a1 <= x1 <= a1 + 120 and b1 <= y1 <= b1 + 120:
                f = True
            else:
                f = False
            if f:
                if self.food == 0:
                    check -= 10
                    print("-10 очков")
                    print("Общий счет:", check)
                    flag_p = True
                else:
                    check += 10
                    print("+10 очков")
                    print("Общий счет:", check)
                all_sprites.remove(self)
                horizontal_borders.remove(self)
        else:
            if self.rect.y < 750:
                self.rect.y += 1
            elif self.rect.y >= 750 and self.food == 1:
                print("Штраф: -10 очков")
                check -= 10
                print("Общий счет:", check)
                all_sprites.remove(self)
                flag_p = True
            else:
                all_sprites.remove(self)
                horizontal_borders.remove(self)


if __name__ == '__main__':
    dict_image = {}
    for i in xxx:
        dict_image[i[0]] = load_image(i)
    screen.fill((0, 0, 0))
    all_sprites1 = pygame.sprite.Group()
    sprite1 = pygame.sprite.Sprite()
    sprite1.image = load_image(["kur.png", 100, 100])
    sprite1.rect = sprite1.image.get_rect()
    all_sprites1.add(sprite1)
    sprite1.rect.x = 5
    sprite1.rect.y = 20
    pygame.mouse.set_visible(False)
    start_screen()
    rules()
    pygame.mouse.set_visible(False)
    size = width, height = 700, 750
    screen = pygame.display.set_mode(size)
    all_sprites = pygame.sprite.Group()
    sprite = pygame.sprite.Sprite()
    running = True
    flag_p = False
    a = []
    check = 0
    sss, kol = 0, 50
    znach = -100
    list_k = [4, 3, 3, 2]
    horizontal_borders = pygame.sprite.Group()
    fps = 100
    ind = 1
    tru = False
    check_list = []
    f1 = pygame.font.Font(None, 56)
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                pr = event.pos
                all_sprites.update(pr)
            if event.type == pygame.MOUSEMOTION:
                sprite1.rect.x = event.pos[0]
                sprite1.rect.y = event.pos[1]
            if check <= -50:
                end_screen(znach)
            if check >= 600:
                f1 = pygame.font.Font(None, 56)
                text1 = f1.render('Счёт: %s' % (check), True, (200, 0, 0))
                screen.blit(text1, (0, 5))
                tru = True
        if tru:
            if len(all_sprites) == 0:
                running = False
                end_screen_true(check)
                break
        else:
            if sss == kol:
                Food([random.randint(5, 550), 0])
                sss = 0
                if check == 0:
                    check_list = []
                elif check == 110:
                    check_list = []
                elif check == 460:
                    check_list = []
                if len(check_list) == list_k[ind] or check < -50:
                    running = False
                    end_screen(check)
                elif check < 0:
                    kol = 100
                    fps = 40
                    ind = 0
                elif 0 <= check <= 100:
                    kol = 50
                    fps = 100
                    ind = 1
                elif 100 < check <= 450:
                    kol = 50
                    fps = 200
                    ind = 2
                elif check > 450:
                    kol = 50
                    fps = 280
                    ind = 3
                if check >= 600:
                    running = False
                    f1 = pygame.font.Font(None, 56)
                    text1 = f1.render('Счёт: %s' % (check), True, (200, 0, 0))
                    screen.blit(text1, (0, 5))
                    running = False
                    end_screen_true(check)
                    break
            if flag_p:
                check_list.append(1)
                flag_p = False
        sss += 1
        try:
            screen.fill((0, 0, 0))
            screen.blit(list_image[ind], (0, 0))
            all_sprites.draw(screen)
            all_sprites1.draw(screen)
            text1 = f1.render('Счёт: %s' % (check), True, (200, 0, 0))
            screen.blit(text1, (0, 5))
            a = []
            all_sprites.update()
            pygame.display.flip()
            clock.tick(fps)
        except:
            sql_table(check)
